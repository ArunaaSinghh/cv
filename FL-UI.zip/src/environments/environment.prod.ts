export const environment = {
  production: true,
  apiBaseUrl: '/crmdod/api',
};
