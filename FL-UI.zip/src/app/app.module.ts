import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HttpXhrBackend } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
  MatInputModule, MatButtonModule, MatSelectModule,MatTableModule, MatRadioModule, MatListModule, MatToolbarModule, MatTooltipModule,
  MatCardModule, MatStepperModule, MatNativeDateModule , MatSlideToggleModule , MatSnackBarModule
} from '@angular/material';
import {MatSidenavModule} from '@angular/material/sidenav';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatChipsModule } from '@angular/material/chips';
import { MatIconModule } from '@angular/material/icon';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDividerModule } from '@angular/material/divider';
import { MatMenuModule } from '@angular/material/menu';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import {ScrollingModule} from '@angular/cdk/scrolling';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { RepairsComponent } from './repairs/repairs.component';
import { HeaderComponent } from './header/header.component';
import { TilesComponent } from './tiles/tiles.component';
import { LtRepairComponent } from './lt-repair/lt-repair.component';
import { LoginComponent } from './login/login.component';
import { RestService } from './rest.service'

@NgModule({
  entryComponents: [],

  declarations: [
    AppComponent,
    RepairsComponent,
    HeaderComponent,
    TilesComponent,
    LtRepairComponent,
    LoginComponent,
  ],
  imports: [
    NgbModule.forRoot(),
    RouterModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    MatListModule,
    BrowserAnimationsModule,
    MatExpansionModule,
    MatInputModule,
    MatAutocompleteModule,
    MatMomentDateModule,
    MatChipsModule,
    MatButtonModule,
    MatSelectModule,
    MatMenuModule,
    MatRadioModule,
    MatCardModule,
    MatTableModule,
    MatStepperModule,
    MatSlideToggleModule,
    MatDividerModule,
    MatIconModule,
    ReactiveFormsModule,
    MatDatepickerModule,
    MatTooltipModule,
    MatToolbarModule,
    MatDialogModule,
    MatNativeDateModule,
    MatSnackBarModule,
    HttpClientModule,
    MatProgressSpinnerModule,
    ScrollingModule,
    MatSidenavModule
  ],
  providers: [RestService],
  bootstrap: [AppComponent]
})
export class AppModule { 
  
}
