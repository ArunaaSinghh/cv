import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { MatSnackBar } from '@angular/material';
import { GadgetsService } from '../gadgets.service';
import { Mobile } from '../interfaces';


@Component({
  selector: 'app-repairs',
  templateUrl: './repairs.component.html',
  styleUrls: ['./repairs.component.css']
})
export class RepairsComponent implements OnInit {
  fcmobrand = new FormControl('');
  fcmodel = new FormControl('');
  mobile: Mobile;
  mobiles: Mobile[] = [];
  options: string[] = [
    "SAMSUNG",
    "APPLE",
    "XIAOMI ",
    "REALME",
    "VIVO",
    "OPPO",
    "HONOUR",
    "NOKIA",
    "ASUS ",
    "ONEPLUS",
    "HUAWEI",
    "LENOVO",
    "MOTO",
    "XIAOMI POCO",
    "10.OR",
    "GIONEE",
    "LG",
    "SONY",
    "INFINIX",
    "LAVA",
    "PANASONIC",
    "GOOGLE MOBILE",
    "COMIO",
    "TECNO",
    "INFOCUS",
    "YU MOBILE PHONE",
    "ITEL",
    "BLACKBERRY",
    "HTC",
    "INTEX",
    "KARBONN",
    "JIVI",
    "COOLPAD",
    "VOTO",
    "SPICE",
    "IBALL",
    "CELKON",
    "LYF",
    "ZENN",
    "XOLO",
    "SWIPE",
    "ALCATEL",
    "LEPHONE",
    "MICROSOFT",
    "SANSUI",
    "VIDEOCON",
    "IDEA"
  ];

  issues: [
    "A",
    "B",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "I"
  ];
  filteredOptions: Observable<string[]>;
  mobileForm: FormGroup;

  constructor(private fb: FormBuilder, public snackBar: MatSnackBar, public gadgetservice: GadgetsService) { }

  ngOnInit() {

    this.getmobiles();
    this.mobileForm = this.fb.group({
      fcmobrand: [null],
      fcmodel: [null],
    
    });
    this.filteredOptions = this.mobileForm.get('fcmobrand').valueChanges
      .pipe(
        startWith(''),
        map(value => this._filterMobiles(value))
      );
  }

  getmobiles() {
    this.gadgetservice.getmobiles()
      .subscribe((mobiles) => {
        console.log(mobiles)
        this.mobiles = mobiles;
        this.mobileForm.get('fcmobrand').setValue('');
      });
  }

  MobileSelected(event: any) {
    const _src = event.option.value;
    this.mobile = _src;
    this.mobileForm.get('fcmodel').setValue(this.mobile)
  }

  getMobiles(model: Mobile) {
    return model;
  }

  private _filterMobiles(value: any): string[] {
    const filterValue = value.toLowerCase();

    return this.options.filter(option => option.toLowerCase().includes(filterValue));
  }

  OnMbSubmit(){
    this.fcmobrand = this.mobileForm.value.fcmobrand;
    this.fcmodel = this.mobileForm.value.fcmodel;
    alert("The Mobile Issues has been sent successfully");
  }
}