import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LtRepairComponent } from './lt-repair.component';

describe('LtRepairComponent', () => {
  let component: LtRepairComponent;
  let fixture: ComponentFixture<LtRepairComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LtRepairComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LtRepairComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
