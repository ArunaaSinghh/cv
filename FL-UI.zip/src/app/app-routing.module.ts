import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RepairsComponent } from './repairs/repairs.component';
import { TilesComponent } from './tiles/tiles.component';
import {LtRepairComponent } from './lt-repair/lt-repair.component';

const routes: Routes = [

  { path: '*', redirectTo: 'tiles' },
  { path: 'tiles', component: TilesComponent },
  { path: 'repairs', component: RepairsComponent },
  { path: 'lt-repair', component: LtRepairComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }