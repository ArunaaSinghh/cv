import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormControl, AbstractControl, FormArray } from '@angular/forms';
import { MasterService } from '../master.service';
import { MatSnackBar } from '@angular/material';
import { Observable } from 'rxjs';
import { map, startWith, findIndex } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ShipToParty, Payer, PaymentMethod, PaymentTerm } from '../agent';
import { TooltipPosition } from '@angular/material';


import { DateAdapter, MAT_DATE_FORMATS, NativeDateAdapter } from '@angular/material';
import { DatePipe } from '@angular/common';
import { Material, Plant } from '../agent';

// import { DialogService } from '../Services/dialog.service';
import * as $ from "jquery";
import { GetAllocationService } from '../Services/get-allocation.service';
import { IAllocation } from '../Mock-allocation';
import { BeforSubmitDialogService } from '../before-submit-dialog.service';
// declare var $: any;
// import * as $ from "../../../node_modules/jquery/dist/jquery.js";


const ELEMENT_DATA: IAllocation[] = [];

export const PICK_FORMATS = {
  parse: { dateInput: { month: 'short', year: 'numeric', day: 'numeric' } },
  display: {
    dateInput: 'input',
    monthYearLabel: { year: 'numeric', month: 'short' },
    dateA11yLabel: { year: 'numeric', month: 'long', day: 'numeric' },
    monthYearA11yLabel: { year: 'numeric', month: 'long' }
  }
};
class PickDateAdapter extends NativeDateAdapter {
  format(ReqDate: Date, displayFormat: Object): string {
    if (displayFormat === 'input') {
      return new DatePipe('en-US').transform(ReqDate, 'dd-MM-yyyy');
    } else {
      return ReqDate.toDateString();
    }
  }
}


@Component({
  selector: 'app-side-menu',
  templateUrl: './side-menu.component.html',
  styleUrls: ['./side-menu.component.css'],
  providers: [
    { provide: DateAdapter, useClass: PickDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: PICK_FORMATS }
  ]
})
export class SideMenuComponent implements OnInit {
  customerForm: FormGroup;
  events: string[] = [];
  opened: boolean;

  fcsoldto = new FormControl('');

  fcshipto = new FormControl('');
  shipToParty: ShipToParty;
  shiptoparties: ShipToParty[] = [];

  fcBillto = new FormControl('');

  fcpayer = new FormControl('');
  payerr: Payer;
  payerrs: Payer[] = [];

  fcpaymeth = new FormControl('');
  paymentMeth: PaymentMethod;
  PaymentMethods: PaymentMethod[] = [];

  fcpayterm = new FormControl('');
  paymentTerm: PaymentTerm;
  PaymentTerms: PaymentTerm[] = [];

  filteredpayers: Observable<Payer[]>;
  filteredshiptoparties: Observable<ShipToParty[]>;
  filteredpaymentmeths: Observable<PaymentMethod[]>;
  filteredpaymentterms: Observable<PaymentTerm[]>;

  // ----------material-plant----------
  positionOptions: TooltipPosition[] = ['below'];
  position = new FormControl(this.positionOptions[0]);

  private mastersub: any = {};
  dataSource = ELEMENT_DATA;
  materialForm: FormGroup;
  fcmat = new FormControl('');
  fcplant = new FormControl('');
  fcqty: Number;
  allocationForm: FormGroup;
  value = 'Clear me';
  ref: string;
  private finalsubmitorder: any = {};
  selectionObj: any;

  alloc_date = new FormControl('');
  dod_date = new FormControl('');
  alloc_qty = new FormControl('');

  material: Material;
  materials: Material[] = [];

  plant: Plant;
  plants: Plant[] = [];

  filteredmaterials: Observable<Material[]>;
  filteredplants: Observable<Plant[]>;

  today = new Date();
  todayMils = this.today.getTime();
  date = this.today.getDate();
  month = this.today.getMonth() + 1;
  year = this.today.getFullYear();
  LastDay = new Date().setFullYear(this.year, this.month, 0);

  ReqDate = new FormControl(new Date());
  minDate = this.today.toISOString().slice(0, -1);
  maxDate = new Date(this.date + this.LastDay).toISOString().slice(0, -1);

  @ViewChild('quantity') quantity;

  // -------------allocation details
  mySlideOptions = {
    items: 4, dots: true, nav: false, stagePadding: 40, loop: false,
    margin: 0,
    responsive: {
      0: {
        items: 1
      },
      600: {
        items: 3
      },
      1000: {
        items: 7
      }
    }
  };

  public cardContent = [];


  constructor(private _getallocationservice: GetAllocationService,
    private dialogservice: BeforSubmitDialogService,
    private http: HttpClient, private fb: FormBuilder,
    private masterservice: MasterService, public snackBar: MatSnackBar) { }

  startData: any
  ngOnInit() {
    // console.log(JSON.parse(sessionStorage.getItem("MYSAPSSO2")));
    this.masterservice.getmasterdet()
      .subscribe((masterResponse) => {

        this.shiptoparties = []
        this.payerrs = []
        this.PaymentMethods = []
        this.PaymentTerms = []

        if (masterResponse && (masterResponse.CustomerData.length > 0)) {
          console.log(masterResponse)
          for (var i = 0; i < masterResponse.CustomerData.length; i++) {
            for (var j = 0; j < masterResponse.CustomerData[i].sh_codes.length; j++) {
              this.shiptoparties.push(masterResponse.CustomerData[i].sh_codes[j])
            }
          }
          for (var k = 0; k < this.shiptoparties.length; k++) {
            for (var l = 0; l < this.shiptoparties[k].payer_codes.length; l++) {
              this.payerrs.push(this.shiptoparties[k].payer_codes[l])
            }
          }

          this.PaymentMethods = masterResponse.PaymentMethod[masterResponse.PaymentMethod.findIndex(x=>x.Payer_Code = masterResponse.Favorite.payer_code)].pay
          this.PaymentTerms = masterResponse.PaymentTerm[0].pay
          
          this.customerForm.patchValue({
            fcshipto: this.shiptoparties[this.shiptoparties.findIndex(x => x.sh_name = masterResponse.Favorite.sh_name)],
            fcsoldto: masterResponse.Favorite.sp_name,
            fcBillto: masterResponse.Favorite.bp_name,
            fcpayer: this.payerrs[this.payerrs.findIndex(x => x.payer_name = masterResponse.Favorite.payer_name)],
            fcpaymeth: this.PaymentMethods[this.PaymentMethods.findIndex(x => x.payment_method = masterResponse.Favorite.payment_method)],
            fcpayterm: this.PaymentTerms[this.PaymentTerms.findIndex(x => x.paymentterm = masterResponse.Favorite.paymentterm)],
          })

          this.materials = [];
          this.materials = masterResponse.Material.material;
          this.plants = masterResponse.Material.material[0].plant;
          // this.plants = this.materials[this.materials.findIndex(x=>x.matcode=masterResponse.Favorite.matcode)].plant
          console.log(this.plants);

          this.materialForm.patchValue({
            fcmat: this.materials[this.materials.findIndex(x=>x.matcode=masterResponse.Favorite.matcode)],
            // fcplant: this.plants,
         
            // fcplant: this.plants[0].plantcode
          })

          console.log(this.materialForm.value)
          let defaultPlants = [];
          defaultPlants.push(this.plants[0])
          defaultPlants.push(this.plants[1])
          defaultPlants.push(this.plants[0])
          // [this.plants.findIndex(x=>x.plantcode=masterResponse.Favorite.plantcode)]
          this.materialForm.get('fcplant').setValue(defaultPlants) 
          // this.materialForm.get('fcmat').setValue(this.materials[0]);
        }
        else {
          this.STP("");
        }
      });


    this._getallocationservice.getallocation()
      .subscribe(data => {
        console.log(data)
        this.cardContent = data.Allocationdata;
        this.calculateSubtotal(false);
      }
      );

    // this.getShipToParties();
    // this.getPaymentMethod();
    // this.getPaymentTerm();
    // this.getMaterials();
    // this.shiptoparties = [];

    this.customerForm = this.fb.group({
      fcshipto: [null, Validators.required],
      fcsoldto: [null, Validators.required],
      fcBillto: [null, Validators.required],
      fcpayer: [null, Validators.required],
      fcpaymeth: [null, Validators.required],
      fcpayterm: [null, Validators.required],
    });

    this.filteredshiptoparties = this.customerForm.get('fcshipto').valueChanges
      .pipe(
        startWith(''),
        map(value => this._filterShipToParties(value))
      );

    this.filteredpayers = this.customerForm.get('fcpayer').valueChanges
      .pipe(
        startWith(''),
        map(value => this._filterpayers(value))
      )

    this.filteredpaymentmeths = this.customerForm.get('fcpaymeth').valueChanges
      .pipe(
        startWith(''),
        map(value => this._filterpaymentmeths(value))
      )
    this.filteredpaymentterms = this.customerForm.get('fcpayterm').valueChanges
      .pipe(
        startWith(''),
        map(value => this._filterpaymentterms(value))
      )

    this.materialForm = this.fb.group({
      fcmat: [null],
      fcplant: [null],
      fcqty: [null, (Validators.maxLength(13))],
      ReqDate: [null]
    });
    // -------------------material-plant------------

    this.allocationForm = this.fb.group({
      fcFormArray: this.fb.array([
      ])

    });

    this.materialForm.controls['ReqDate'].setValue(new Date().toISOString().slice(0, 10));
    // this.materialForm.get('fcplant').setValue('RIL FARIDABAD');
    // this.materialForm.get('fcqty').setValue('21');


    this.filteredmaterials = this.materialForm.get('fcmat').valueChanges
      .pipe(
        startWith(''),
        // map(value => typeof value === 'string' ? value : value.matdesc),
        map(value => this._filtermaterials(value))
      )

    // this.filteredplants = this.materialForm.get('fcplant').valueChanges
    //   .pipe(
    //     startWith(''),
    //     map(value => this._filterplants(value))
    //   )
  }




  subTotal: any;
  quantityTotal: number;
  calculateSubtotal(valueChange: boolean) {
    this.subTotal = [];
    this.quantityTotal = 0;
    console.log('this.cardContent', this.cardContent);


    this.cardContent.forEach((key, value) => {

      // console.log('key', key);

      let sum = 0;
      key.allocation.forEach(k => {

        // console.log('k', k);
        if (!valueChange) {
          k.selected ? k.input_qty = k.alloc_qty : k.input_qty = 0;
          k.crm_number = ""; 
        }
        sum += Number(k.input_qty);
      })

      this.quantityTotal += sum;
      this.subTotal.push({ index: value, sumValue: sum });
    });

    console.log('this.quantityTotal', this.quantityTotal);
    console.log('this.subTotal', this.subTotal);
  }

  getValue(dates: any) {
    if (dates.selected == true) {
      return dates.alloc_qty
    }
    else {
      return 0
    }
  }

  tileSelect(event: any, objDates: any) {

    console.log('objDates', objDates);



    if (event.srcElement.closest(".calendarcard").classList.contains("selected-tile")) {

      objDates.input_qty = 0;

      event.srcElement.closest(".calendarcard").classList.remove("selected-tile")

      this.calculateSubtotal(true);
    }
    else {
      event.srcElement.closest(".calendarcard").classList.add("selected-tile")
      objDates.input_qty = Number(objDates.alloc_qty);
 this.calculateSubtotal(true);
    }
  }




  shipselected(event: any) {
    const _src = event.option.value;
    this.shipToParty = _src;
    this.payerrs = _src.payer_codes;

    this.customerForm.get('fcsoldto').setValue(this.shipToParty.sp_name)
    console.log(_src);
    this.customerForm.get('fcBillto').setValue(this.shipToParty.bp_name)
    this.customerForm.get('fcpayer').setValue(this.payerrs[0])
    // this.customerForm.get('fcpaymeth').setValue(this.PaymentMethods[0].payment_methoddesc)
    // this.customerForm.get('fcpayterm').setValue(this.PaymentTerms[0].ptdesc)
    // this.customerForm.get('fcBillto').setValue(this.billToParties[0].bp_name)

  }

  getShipToParty(shiptoparty: ShipToParty) {
    return shiptoparty ? shiptoparty['sh_name'] : undefined;
  }

  getPayer(pay: Payer) {

    return pay ? pay['payer_name'] : undefined;
  }


  PayerSelected(event: any) {
    const _src = event.option.value;
    this.payerr = _src;
    // this.getPaymentMethod()

    // this.PaymentMethods = _src.payment_method;
  }

  getPayMeth(paymeth: PaymentMethod) {
    return paymeth ? paymeth['payment_methoddesc'] : undefined;
  }

  PaymethSelected(event: any) {
    const _src = event.option.value;
    this.paymentMeth = _src;
    console.log(this.paymentMeth);

    // this.materialForm.controls['fcpayterm'].setValue('')
    // this.getPaymentTerm()

  }

  getPayTerm(payterm: PaymentTerm) {
    return payterm ? payterm['ptdesc'] : undefined;
  }


  PaytermSelected(event: any) {
    const _src = event.option.value;
    this.paymentTerm = _src;
    console.log(this.paymentTerm);
  }

  STP(message: any) {
    this.snackBar.open("Ship To Party Not Found \n" + message, "", { duration: 10000 });
  }

  alloc_message(message: any) {
    this.snackBar.open("Allocation Not Found \n" + message, "", { duration: 10000 });
  }


  private _filterShipToParties(value: any): ShipToParty[] {
    let filterValue = '';
    if (typeof value === 'object') {
      filterValue = value ? value.sh_name.toLowerCase() : '';
    } else {
      filterValue = value ? value.toLowerCase() : '';
    }
    //  console.log(obj);
    return this.shiptoparties.filter(option => (option.sh_name.toLowerCase().includes(filterValue) ||
      option.sh_code.toLowerCase().includes(filterValue)) ? option : '');
  }

  private _filterpayers(value: any): Payer[] {
    let filterValue = '';
    if (typeof value === 'object') {
      filterValue = value ? value.payer_name.toLowerCase() : '';
    } else {
      filterValue = value ? value.toLowerCase() : '';
    }
    //  console.log(obj);
    return this.payerrs.filter(option => (option.payer_name.toLowerCase().includes(filterValue) ||
      option.payer_code.toLowerCase().includes(filterValue)) ? option : '');
  }

  private _filterpaymentmeths(value: any): PaymentMethod[] {
    let filterValue = '';
    if (typeof value === 'object') {
      filterValue = value ? value.payment_methoddesc.toLowerCase() : '';
    } else {
      filterValue = value ? value.toLowerCase() : '';
    }
    //  console.log(obj);
    return this.PaymentMethods.filter(option => (option.payment_methoddesc.toLowerCase().includes(filterValue) ||
      option.payment_method.toLowerCase().includes(filterValue)) ? option : '');
  }

  private _filterpaymentterms(value: any): PaymentTerm[] {
    let filterValue = '';
    if (typeof value === 'object') {
      filterValue = value ? value.ptdesc.toLowerCase() : '';
    } else {
      filterValue = value ? value.toLowerCase() : '';
    }
    //  console.log(obj);
    return this.PaymentTerms.filter(option => (option.ptdesc.toLowerCase().includes(filterValue) ||
      option.paymentterm.toLowerCase().includes(filterValue)) ? option : '');
  }

  getMaterials() {
    this.masterservice.getmasterdet()
      .subscribe((materials) => {
        if (materials && materials.Material.material.length > 0) {
          console.log(materials)
          this.materials = materials.Material.material;
          this.plants = this.materials[0].plant;

          this.materialForm.get('fcmat').setValue({ matdesc: materials.Favorite.matdesc});

          this.materialForm.get('fcmat').setValue(this.materials[0]);
          this.materialForm.get('fcplant').setValue(this.plants[0]);

          // const plantselect: any[] = this.plants
          // this.fcplant.setValue(plantselect[0].plantdesc)
          // this.materialForm.controls['fcplant'].setValue(this.plants[0].plantdesc);

          // this.materialForm.controls['fcplant'].setValue(this.plants[0].plantdesc);

          // this.materialForm.get('fcplant').patchValue({
          //   plantcode: materials.Favorite.plantcode,
          //   plantdesc: materials.Favorite.plantdesc
          // });
          // this.materialForm.controls['fcmat'].setValue(this.materials[0].matdesc);
          console.log(this.plants[0].plantdesc);
          // this.materialForm.get('fcplant').setValue(this.plants[0].plantcode);
        }
        else {
          this.MaterialNotFound("");
        }
      });
  }

  onSearch() {
    console.log("datasourse before", this.cardContent)
    console.log("fc plants", this.materialForm.value.fcplant)
    this.mastersub = Object.assign(this.mastersub, this.customerForm.value, this.materialForm.value, this.cardContent[0]);
    this.fcqty = this.materialForm.value.fcqty;
    // this.dataSource = [];
    console.log(this.mastersub,  this.materialForm.value.fcplant[0])
    // this.mastersub.location = this.plants[this.plants.findIndex(x=>x.plantdesc = this.materialForm.value.fcplant[0].plantdesc)].plantcode
    console.log("this is location", this.mastersub.location)
    // this.mastersub = Object.assign(this.mastersub, location);
   
    this.masterservice.fetchAllocation(this.mastersub)
    .subscribe(
      (res:any)=>{
        console.log(res)
      if(res.success==true){
        this.cardContent = []
        this.cardContent[0] = res.data
        for(var k=0; k<this.cardContent[0].allocation.length;k++){
          if(this.cardContent[0].allocation[k].selected){
            this.cardContent[0].allocation[k].input_qty =  this.cardContent[0].allocation[k].alloc_qty
            
    this.calculateSubtotal(false);
          }else{
            this.cardContent[0].allocation[k].input_qty = 0
            this.calculateSubtotal(false);
          }
        }
        console.log("datasoure after", res.data)
        // this.dataSource = res.data.allocation;
      }
    })

    // this.masterservice.getmasterdet()
    //   .subscribe((masterResponse) => {
    //     this.materials = [];
    //     this.materials = masterResponse.Material.material;
    //     this.plants = this.materials[this.materials.findIndex(x=>x.matcode=masterResponse.Favorite.matcode)].plant
    //     console.log(this.plants);

    //     this.materialForm.patchValue({
    //       fcmat: this.materials[this.materials.findIndex(x=>x.matcode=masterResponse.Favorite.matcode)],
    //       // fcplant: this.plants,
       
    //       // fcplant: this.plants[0].plantcode
    //     })
    //   })
    
    // this.calculateSubtotal(true);
    // this.ReqDate = this.materialForm.value.ReqDate;
    // this.dataSource = [];
    // this.masterservice.fetchAllocation(this.mastersub)
    //   .subscribe((res: any) => {
    //     let data: any = [];
    // console.log('res', res);
    // let DeliveryOptionsArray: any = [];
    // if (res.success == true) {
    //   this.allocationForm.value.fcFormArray.push(res.Alloctiondata[0].allocation);
    //   this.allocationForm.get("fcFormArray").value.forEach(function (value) {
    //     let DeliveryOptions = {
    //       alloc_qty: value.get("alloc_qty").value,
    //       dod_date: value.get("dod_date").value,
    //       alloc_date: value.get("alloc_date").value,
    //     };
    //     DeliveryOptionsArray.push(DeliveryOptions);
    //   });
    //   {
    //     this.alloc_qty = res[0].allocation[0].alloc_qty;
    //     this.dod_date = res[0].allocation[0].dod_date;
    //     this.alloc_date = res[0].allocation[0].alloc_date;

    //   }

    //   data.push(res[0])
    //   this.dataSource = data;
    // }

    // for (var q = 0; q < this.startData.CustomerData.length; q++) {
    //       for (var w = 0; w = this.startData.CustomerData[q].sh_codes.length; w++) {
    //         var ShipToParty = {
    //           sh_code: this.startData.CustomerData[q].sh_codes[w].sh_code,
    //           sh_name: this.startData.CustomerData[q].sh_codes[w].sh_name
    //         }
    //         // this.shiptoparties.push(ShipToParty)
    //         this.startData.CustomerData[q].sh_codes[w]
    //       }
    //     }
    // for (var q = 0; q < this.cardContent[0].allocation.length; q++) {
    //   if (this.fcqty = + this.cardContent[0].allocation[q].alloc_qty) {
    //     this._getallocationservice.getallocation()
    //       .subscribe(data => {
    //         this.dataSource = data.Allocationdata[q];
    //         this.calculateSubtotal(false);
    //       })
    //   }
    // }
  } 

  selectionArray: any = [];
  fullView(index: number) {

    let value = this.selectionArray.filter(obj => obj == index);
    console.log('value', value);
    if (value && value.length > 0) {
      let itemIndex = this.selectionArray.indexOf(value);
      this.selectionArray.splice(itemIndex, 1);
    } else {
      this.selectionArray.push(index);
    }
  }

  compactView(index: number) {
    // this.selectionArray.push(index);
  }

  getmaterial(mat: Material) {
    return mat ? mat['matdesc'] : undefined;
  }


  MaterialNotFound(message: any) {
    this.snackBar.open("Material Not Found \n" + message, "", { duration: 10000 });
  }

  MaterialSelected(event: any) {
    const _src = event.option.value;
    this.material = _src;
    console.log(this.material)
    this.plants = _src.plant;
    this.materialForm.get('fcplant').setValue('')
  }

  getplant(plantt: Plant) {
    return plantt ? plantt['plantdesc'] : undefined;
  }

  PlantSelected(event: any) {
    const _src = event.option.value;
    this.plant = _src;
  }


  private _filtermaterials(value: any): Material[] {
    let filterValue = '';
    if (typeof value === 'object') {
      filterValue = value ? value.matdesc.toLowerCase() : '';
    } else {
      filterValue = value ? value.toLowerCase() : '';
    }
    //  console.log(obj);
    return this.materials.filter(option => (option.matdesc.toLowerCase().includes(filterValue) ||
      option.matcode.toLowerCase().includes(filterValue)) ? option : '');
  }

  private _filterplants(value: any): Plant[] {
    let filterValue = '';
    if (typeof value === 'object') {
      filterValue = value ? value.plantdesc.toLowerCase() : '';
    } else {
      filterValue = value ? value.toLowerCase() : '';
    }
    //  console.log(obj);
    return this.plants.filter(option => (option.plantdesc.toLowerCase().includes(filterValue) ||
      option.plantcode.toLowerCase().includes(filterValue)) ? option : '');
  }


  successSnackbar() {
    this.snackBar.open(this.ref , "close", { duration: 10000 });
  }

postBodyFinal = []
  postBodyFinalAllocationArray = []


  onSubmit() {
    var postBodyFinalObj = null

    console.log(this.customerForm.value);
    console.log(this.materialForm.value);

    this.selectionObj = {
      customerSelection: this.customerForm.value,
      materialSelection: this.materialForm.value,
      allocationSelection: this.cardContent,
      totalQuantity: this.quantityTotal
    }

    console.log(this.selectionObj)
    this.dialogservice.orderConfirmationDialog("Do You Want To Submit Your Order!", this.selectionObj)

      .afterClosed().subscribe(res => {
        console.log(res, this.selectionObj)

        if (res == true) {
          this.postBodyFinal = []
          // for(var t=0; t<this.materials.plant.length; t++)
          
          for(var s=0;s<this.selectionObj.allocationSelection[0].allocation.length;s++){
            if(this.selectionObj.allocationSelection[0].allocation[s].input_qty>0){
              var timepass ={
                deliverydate : this.selectionObj.allocationSelection[0].allocation[s].alloc_date,
                transitdate : this.selectionObj.allocationSelection[0].allocation[s].dod_date,
                quantity : this.selectionObj.allocationSelection[0].allocation[s].input_qty,
                CRMOrderNumber : ""
              }
              this.postBodyFinalAllocationArray.push(timepass)}
          }

          postBodyFinalObj = {
            "business" : {
              "agentCode" : "MOBUSER",
              "SalesOrgCode" : "1010",
             "DistChnlCode" : "10",
              "DivisionCode" : "23"
            },
            "soldtoParty" : {
              "code" : "200000178",
              "name" : this.selectionObj.customerSelection.fcsoldto,
              "gcCode" : this.selectionObj.allocationSelection[0].group_customer
            },
            "shiptoParty" : {
              "code" : this.selectionObj.allocationSelection[0].ship_to_party,
              "name" : this.selectionObj.customerSelection.fcshipto.sh_name,
              "tzone" : this.selectionObj.customerSelection.fcshipto.t_zone,
              "address" : this.selectionObj.customerSelection.fcshipto.sh_address
            },
            "billtoParty" : {
              "code" : this.selectionObj.customerSelection.fcshipto.bp_code,
              "name" : this.selectionObj.customerSelection.fcshipto.bp_name,
              "regNum" : this.selectionObj.customerSelection.fcshipto.reg_no,
            },
            "payer" : {
              "code" : this.selectionObj.customerSelection.fcpayer.payer_code,
              "name" : this.selectionObj.customerSelection.fcpayer.payer_name
            },
            "paymentMethod" : {
              "code" : this.selectionObj.customerSelection.fcpaymeth.payment_method,
              "name" : this.selectionObj.customerSelection.fcpaymeth.payment_methoddesc
            },
            "paymentTerm" : {
              "code" : this.selectionObj.customerSelection.fcpayterm.paymentterm,
              "name" : this.selectionObj.customerSelection.fcpayterm.ptdesc
            },
            "material" : {
              "matCode" : this.selectionObj.materialSelection.fcmat.matcode,
              "matDesc" : this.selectionObj.materialSelection.fcmat.matdesc,
              "HSNCode" :  this.selectionObj.materialSelection.fcmat.HSNcode,
              "uom" : "MT"
            },
            "plant" : {
              "plantCategory" : "PC1",
              "plantCode" :   this.selectionObj.materialSelection.fcmat.plant[0].plantcode,
              "plantDesc" :   this.selectionObj.materialSelection.fcmat.plant[0].plantdesc,
              "GSTNo" : "AZIXAPIABN617681"
            },
            "totquantity" : "80",
            "deliveryDate" : "2018-11-05T11:11:00",
            "status":"Submitted",
            "shipopt" : this.postBodyFinalAllocationArray
          
          // this.postBodyFinal.push(postBodyFinalObj)
        }

        console.log("This was posted:", postBodyFinalObj)

          this._getallocationservice.postSummary(postBodyFinalObj)
            .subscribe(
              (response: any) => {
                console.log('response',response);
                let resSTR = JSON.stringify(response);
                let resJSON = JSON.parse(resSTR);
                this.ref = resJSON.message;
                this.successSnackbar();
                

              },

            );
           
        }
        else {

        }
      });

  

  }

  quantityChanged(event: any) {

    this.calculateSubtotal(true);

    if (event.srcElement.value != 0) {

      event.srcElement.closest(".calendarcard").classList.add('selected-tile')
    }
    else {
      event.srcElement.closest(".calendarcard").classList.remove('selected-tile')

    }
  }

}


