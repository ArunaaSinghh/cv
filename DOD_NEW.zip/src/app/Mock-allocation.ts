export interface IAllocation {
   alloc_qty: number,
   dod_date: Date,
   alloc_date: Date,
   flag: string
}