import { TestBed } from '@angular/core/testing';

import { BeforeSubmitDialogService } from './before-submit-dialog.service';

describe('BeforeSubmitDialogService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BeforeSubmitDialogService = TestBed.get(BeforeSubmitDialogService);
    expect(service).toBeTruthy();
  });
});
