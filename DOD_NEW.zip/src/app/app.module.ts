import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import {MatToolbarModule} from '@angular/material/toolbar';
import {MatIconModule} from '@angular/material/icon';
import { DODHeaderComponent } from './dod-header/dod-header.component';
import {MatSliderModule} from '@angular/material/slider';
import {MatFormFieldModule} from '@angular/material/form-field';
import { OwlModule } from 'ngx-owl-carousel';
import { GetAllocationService } from './Services/get-allocation.service';

import { SideMenuComponent } from './side-menu/side-menu.component';
import { MasterService } from './master.service';

import { FormsModule } from '@angular/forms';
import { HttpClientModule, HttpXhrBackend } from '@angular/common/http';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
  MatInputModule, MatButtonModule, MatSelectModule ,MatTableModule, MatRadioModule, MatListModule, MatTooltipModule,
  MatCardModule, MatStepperModule, MatNativeDateModule , MatSlideToggleModule , MatSnackBarModule
} from '@angular/material';
import {MatSidenavModule} from '@angular/material/sidenav';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatChipsModule } from '@angular/material/chips';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDividerModule } from '@angular/material/divider';
import { MatMenuModule } from '@angular/material/menu';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import {ScrollingModule} from '@angular/cdk/scrolling';
import { BeforeSubmitDialogComponent } from './before-submit-dialog/before-submit-dialog.component';

@NgModule({

  entryComponents: [SideMenuComponent, BeforeSubmitDialogComponent],
  
  declarations: [
    AppComponent, DODHeaderComponent,
    // DodAllocationComponent, MatplantBodyComponent, 
    SideMenuComponent,
    BeforeSubmitDialogComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MatToolbarModule,
    MatIconModule,
    MatButtonModule,
    MatCardModule,
    MatTooltipModule,
    MatSliderModule,
    MatFormFieldModule,
    OwlModule,
    MatInputModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    MatListModule,
    BrowserAnimationsModule,
    MatExpansionModule,
    MatInputModule,
    MatAutocompleteModule,
    MatChipsModule,
    MatButtonModule,
    MatSelectModule,
    MatMenuModule,
    MatRadioModule,
    MatCardModule,
    MatTableModule,
    MatStepperModule,
    MatSlideToggleModule,
    MatDividerModule,
    MatIconModule,
    ReactiveFormsModule,
    MatDatepickerModule,
    MatTooltipModule,
    MatToolbarModule,
    MatDialogModule,
    MatNativeDateModule,
    MatSnackBarModule,
    HttpClientModule,
    MatProgressSpinnerModule,
    ScrollingModule,
    MatSidenavModule
  ],
  providers: [GetAllocationService, MasterService, ],
  bootstrap: [AppComponent]
})
export class AppModule { }
