export interface ShipToParty {
  sh_code: string;
  sh_name: string;
  sh_address: string;
  sh_tzone: string;
  sp_code: string;
  sp_name: string;
  gc_code: string;
  gc_name: string;
  bp_code: string;
  bp_name: string;
  reg_no: string,
  payer_codes:[],
  Favorite: []
}
export interface Payer {
  payer_code: string;
  payer_name: string;
}
export interface PaymentMethod {
  payment_method: string;
  payment_methoddesc: string;
}
export interface PaymentTerm {
  paymentterm: string;
  ptdesc: string;
}
export interface Material {
  matcode: string,
  matdesc: string,
  HSNcode: string,
  uom: string,
  plant: [];
}
export interface Plant {
  plantcode: string,
  plantdesc: string,
  plantcat: string,
  GSTno: string
}


