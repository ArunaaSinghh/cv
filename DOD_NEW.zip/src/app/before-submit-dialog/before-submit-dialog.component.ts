import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-before-submit-dialog',
  templateUrl: './before-submit-dialog.component.html',
  styleUrls: ['./before-submit-dialog.component.css']
})
export class BeforeSubmitDialogComponent implements OnInit {

  objSelection: any;
  constructor(@Inject(MAT_DIALOG_DATA) public data, public dialogref: MatDialogRef<BeforeSubmitDialogComponent>) {
    
    this.objSelection = data;
    console.log('this.objSelection', this.objSelection);
    this.doProcessing();
  }

  ngOnInit() {
  }


  keepGoing: boolean = true;
  showHeader: boolean = false;
  doProcessing() {
    try {
      if (this.objSelection.objSelection.allocationSelection && this.objSelection.objSelection.allocationSelection.length > 0) {
        this.objSelection.objSelection.allocationSelection.forEach((key: any) => {
          let keepGoing: boolean = true;
          key.allocation.forEach((element: any) => {
            if (keepGoing) {
              if (element.input_qty > 0) {
                keepGoing = false;
                key.showHeader = true;
              } else {
                key.showHeader = false;
              }
            }
          });
        });
      }

    } catch (e) {

    }
  }


  closeDialog() {
    this.dialogref.close();
  }


}
