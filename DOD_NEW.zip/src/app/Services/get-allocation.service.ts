import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IAllocation } from '../Mock-allocation';

@Injectable({
  providedIn: 'root'
})
export class GetAllocationService {

  private _url: string = "http://localhost:4000/crmdod/api/v2/agent/MOBUSER";
  constructor(private http: HttpClient ) { }

  getallocation(): Observable<any>{
    return this.http.get<IAllocation[]>(this._url);
  }

  postSummary(mastersub:any){
    // console.log(typeof(ordersummary))
    return this.http.post( "http://localhost:4000/crmdod/api/v2/sendorder", mastersub);
  }

}
