import { TestBed } from '@angular/core/testing';

import { GetAllocationService } from './get-allocation.service';

describe('GetAllocationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GetAllocationService = TestBed.get(GetAllocationService);
    expect(service).toBeTruthy();
  });
});
