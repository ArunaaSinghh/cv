import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from '../environments/environment';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};


@Injectable({
  providedIn: 'root'
})
export class MasterService {
  // private apiBaseUrl = environment.apiBaseUrl;  // URL to web api

  // private url = "http://localhost:4000/custdisp/det/0000602531/1010/23/10";
  private url = "http://localhost:4000/crmdod/api/v2/agent/MOBUSER"

  constructor(private http: HttpClient) {

  }

  getmasterdet(): Observable<any> {
    return this.http.get<any>(this.url)
      .pipe(
        map(response => {  // NOTE: response is of type SomeType

          if (response.success) {
            return response;
          }
          else {
          }
        }),
        tap(_ => this.log('fetched ShipToParties')),
        catchError(this.handleError('getShipToParties', []))
      );
  }

 fetchAllocation(mastersub : any ): Observable<any> {
    console.log("plants selected", mastersub.location)
    let body = {
      "material": mastersub.fcmat.matcode,
      // "location": mastersub.fcplant[0].plantcode,
      "location": mastersub.fcplant[0].plantcode,
      "division": mastersub.division,
      "distribution_channel": mastersub.distribution_channel,
      "group_customer": mastersub.group_customer,
      "ship_to_party": mastersub.ship_to_party,
      "quantity": mastersub.fcqty,
      "date": mastersub.ReqDate
    };
    console.log(body)

    return this.http.post( "http://localhost:4000/crmdod/api/v2/getDODdetails", body);
  }
  /**
* Handle Http operation that failed.
* Let the app continue.
* @param operation - name of the operation that failed
* @param result - optional value to return as the observable result
*/
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      this.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
  /** Log a HeroService message with the MessageService */
  private log(message: string) {
    //  this.messageService.add(`DoDService: ${message}`);
    console.log(`DoDService: ${message}`);
  }
}

