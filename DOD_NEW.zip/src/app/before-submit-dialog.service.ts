import { Injectable } from '@angular/core';
import { MatDialog } from '@angular/material';
import { BeforeSubmitDialogComponent } from './before-submit-dialog/before-submit-dialog.component';

@Injectable({
  providedIn: 'root'
})
export class BeforSubmitDialogService {

  constructor(private dialog: MatDialog) { }

  confirm:boolean
  orderConfirmationDialog(msg: any, selectionObj: any){
    console.log(selectionObj)
    return this.dialog.open(BeforeSubmitDialogComponent,{
      width: '60%',
      height: '70%',
      panelClass: 'confirm-dialog-container',
      disableClose: false,
      data:{
        message: msg,
        confirm: this.confirm,
        objSelection: selectionObj
      }
    });
  }
}
