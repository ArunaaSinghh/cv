import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-dod-header',
  templateUrl: './dod-header.component.html',
  styleUrls: ['./dod-header.component.css']
})
export class DODHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
