import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DODHeaderComponent } from './dod-header.component';

describe('DODHeaderComponent', () => {
  let component: DODHeaderComponent;
  let fixture: ComponentFixture<DODHeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DODHeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DODHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
