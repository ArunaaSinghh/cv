import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-models-show',
  templateUrl: './models-show.component.html',
  styleUrls: ['./models-show.component.css']
})
export class ModelsShowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
