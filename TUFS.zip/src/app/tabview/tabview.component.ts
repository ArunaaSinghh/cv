import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from "@angular/material";
import { SignoutComponent } from "../signout/signout.component";

@Component({
  selector: 'app-tabview',
  templateUrl: './tabview.component.html',
  styleUrls: ['./tabview.component.css']
})
export class TabviewComponent implements OnInit {

  constructor(private dialog: MatDialog) { }

  ngOnInit() {
  }
  OpenDialog() {

    const dialogConfig = new MatDialogConfig();

    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;

    dialogConfig.data = {
      id: 1,
      title: 'You have logged out!'
  };

    this.dialog.open(SignoutComponent, dialogConfig);

  }
}
