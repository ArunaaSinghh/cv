import { Component, OnInit, Injectable, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

export class DialogSubmitService {

  constructor(public dialogRef: MatDialogRef<DialogSubmitService>,
    @Inject(MAT_DIALOG_DATA)

    public data: any) {
    dialogRef.disableClose = true;
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
}