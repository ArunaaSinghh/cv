import { TestBed } from '@angular/core/testing';

import { DialogSubmitService } from './dialog-submit.service';

describe('DialogSubmitService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DialogSubmitService = TestBed.get(DialogSubmitService);
    expect(service).toBeTruthy();
  });
});
