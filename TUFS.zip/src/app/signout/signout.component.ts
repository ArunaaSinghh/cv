import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router'

@Component({
  selector: 'app-signout',
  templateUrl: './signout.component.html',
  styleUrls: ['./signout.component.css']
})
export class SignoutComponent implements OnInit {

  form: FormGroup;
  description: string;

  constructor(private fb: FormBuilder, private router: Router,
    private dialogRef: MatDialogRef<SignoutComponent>,
    @Inject(MAT_DIALOG_DATA) data) {

    this.description = data.description;
  }

  ngOnInit() {
    localStorage.removeItem('session');
  }
  save() {
    this.router.navigateByUrl('issue');
    location.reload(false);
  }

  close() {
    this.dialogRef.close();
  }
}
